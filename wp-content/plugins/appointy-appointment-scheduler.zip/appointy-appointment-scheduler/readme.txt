=== WordPress Appointment Booking and Online Scheduling Plugin by Appointy ===

Contributors: Appointy
Tags: Appointment scheduling, online scheduling, appointment booking, booking calendar, event calendar, class scheduling, class Booking, resource scheduling, book appointment, appointments, book meetings, meeting scheduler, online meeting, appointment calendar, calendar, scheduling, video meeting, availability, booking, appointment, WordPress Appointment Booking, Google Calendar, Appointment Booking Plugin For WordPress Websites, multilingual, Salon Scheduling, SPA scheduling, spa booking, salon booking, appointy, vcita, booking system, booking plugin, appointment booking system, bookings, booking engine, booking form, Booking Software, reservation system, availability calendar, reservations, reservation plugin, reservation calendar, Hotel Booking, Event Booking, Reservation, Class Booking, online booking calendar, online booking software, appointment booking calendar, Rental, Activity Booking, booking portal, online booking, wordpress booking, booking module, reserve form, reserve calendar, beauty salon booking, tour guide booking, restaurant booking, cafe booking, conference room booking, cooking class booking, culture classroom booking, swimming classroom booking, music classroom booking, car rental booking, hospital booking, clinic booking, dentist booking, facility booking, tour booking, booking to visit, private residence booking, venue booking, sports gym booking, booking tennis courts, ship booking, booking a rental cycle, booking theater, Management online booking, spas booking, barber shop booking, hair salon booking, beauty center booking, reservation notifications, online reservation, online reservation system, free calendar,Interactive Calendar, online calendar, web calendar, event, calendar plugin, wordpress calendar, create calendar, simple calendar, book, bookable, calendar widget, events calendar, calendars, holiday calendar, jQuery calendar, google calendar booking system, meeting, calendar shortcode, custom calendar, pick date calendar, date calendar, calendar manager, calendario, calendario de compromissos, calendario de citas, reserva, Kalender, wp kalender, Online Kalender, Online buchung kalender, calendrier, client scheduling, meetings, appointment scheduling software, salon, nutritionist, dentist, chiropractor, fitness, coach, consultant, entrepreneurs,business booking, lawyers, yoga teacher, studios, spas, agendamento de consultas,programación de cita, cita en línea, programación en línea, contratación de cita compromisso, agenda de compromisso, compromisso online, agendamento online, reserva de compromisso, calendário de compromissos, plugin de reserva de compromisso para sites do WordPress, cita, calendario de citas, plugin de contratación para sitios WordPress, planning, prise de rdv wordpress, prise de rendez-vous wordpress, gestion de rdv, rendez-vous, online terminplaner, terminplanung, online terminbuchung, online kalender, terminplaner mit bezahlsystem, online buchung kalender, terminbuchung, консультация,доступность,встречайтесь с клиентами,видеоконференция,календарь,Встреча онлайн,бронирование встреч,планирование встреч,забронировать консультацию
Requires at least: 3.0.1
Requires PHP: 5.6
Tested up to: 5.3.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Trusted by businesses since 2010. Online scheduling & booking plugin that’s reliable, easy to use and feature packed. 24x7 setup & support.

== Description ==

Trusted by businesses since 2010, Appointy is one of the most popular, reliable, and highly rated **appointment scheduling** and **Wordpress booking calendar plugin**. It has all the features that businesses need to accept appointments, calendar bookings and payments 24x7 in one easy-to-use user interface. Additionally, it can also help you: 

1. **Schedule online**: Customers self-schedule anytime, anywhere.
2. **Increase productivity**: Improve staff productivity, manage multiple staff and locations.
3. **Attract customers**: Social promotion via Facebook, Twitter, and Email marketing. Reserve with Google Integration.
4. **Retain customers**: Understand your customers and run customer loyalty programs.

### Appointy has been built from the ground up keeping business growth at its core ###

With Appointy’s super-quick guided setup, (or you may opt for our **Free Done For You setup**), enterprise level customization, built in marketing & analytics features and simplified integration with your website, you will get an instant boost for your business’s revenue, exposure and customer satisfaction.

With its partnership with Google, Appointy also provides you the opportunity to turn Google searchers into paying customers using **Reserve with Google.**

### What can I use Appointy for ? ###

* **Appointment Scheduling** : Schedule services or staff (Hair Salon Booking, Barber Shop booking, Beauty Center Booking, Spa Booking, Acupuncture Booking, Dog Groomers Booking, Massage Therapists Booking, One-to-One coaching, Gym, Dentists Appointment Scheduling, Doctors Appointment Scheduling, Nutritionist Appointment Booking,Fitness Coach booking etc).

* **Class Scheduling** : Yoga Class Scheduling , Dance Class Scheduling, Fitness Class Scheduling , Cooking Class Booking,Culture classroom booking, ,Swimming Class booking, Music class booking etc.

* **Resource Scheduling** : Schedule Resources (Balloon Rides, Real Estates or Agents, Hotel Rooms, Machines, Pools, Courts, Rentals etc.)

* **Event Scheduling /  Event Booking**: Schedule Events with Events Calendar (Single or Multiple occurring events)

* **Meeting Scheduler**: Book Meetings Online

* **Booking Calendar / Appointment Calendar**: Book Calendar, Book Rental, Beauty Salon Booking, Tour Guide Booking, Restaurant Booking, Cafe Booking, Conference Room booking, Car Rental Booking, Hospital Booking, Clinic Booking, Facility Booking, Private Residence Booking

* **Reservations**: Hotel reservation & bookings, Tour Reservations, Reserve Calendar, Any kind of Online Reservations

* **Almost any other business that accepts appointments**

<a href="https://www.appointy.com/?utm_source=wordpress&utm_medium=textdescription&utm_campaign=wptext " target="_blank">Homepage</a> | <a href="https://www.appointy.com/online-appointment-scheduling-software/?utm_source=wordpress&utm_medium=textdescription&utm_campaign=wptext " target="_blank">Appointment Scheduling</a> | <a href="https://www.appointy.com/online-class-scheduling-software/?utm_source=wordpress&utm_medium=textdescription&utm_campaign=wptext " target="_blank">Class Scheduling</a> | <a href="https://www.appointy.com/online-activity-scheduling-software/?utm_source=wordpress&utm_medium=textdescription&utm_campaign=wptext " target="_blank">Activity Scheduling</a> | <a href="https://booking.appointy.com/demospa/?utm_source=wordpress&utm_medium=textdescription&utm_campaign=wptext " target="_blank">Demo</a> 

[vimeo https://vimeo.com/134405724]

### Appointy Features and Pricing ### 

**Free Plan:** 

*Features offered in Free Plan* 
1. No. of Staff Users: 1
2. No. of Services: 5
3. No. of Appointments in a month: 100
4. Clients can schedule appointments 24x7
5. Integration on your website and Facebook page
6. Check Daily, weekly, and monthly availability in just one click
7. Schedule classes, groups, events or individual appointments
8. Zapier Integration
9. Automatic Reminders
10. Mobile App
11. Reschedule appointments
12. Set service dependency
13. Client Verification
14. Automatic appointment assignment to staff
15. Reserve with Google integration
16. CRM Tool
17. 24x7 Customer Support and Free Setup
18. Real Time Notifications
19. SSL Security
20. Accept Payments through Square
21. Instagram and Facebook Integration

**Premium Plans: Growth, Professional, Enterprise** 

*Features offered in Premium Plans:* (All features of the free plan + the features below as per plan type)
1. No. of Staff Users: 1-5 as per plan with option to add more staff members
2. No. of Services: Unlimited
3. No. of Appointments in a month: Unlimited
4. Schedule resources/ equipment/ rooms in addition to staff
5. Service Level Agreement
6. Multi Location Support
7. Recurring bookings
8. Capacity booking
9. Two way Google calendar synchronisation
10. i-Cal feed
11. Office 365 integration
12. Google Analytics
13. Google Tag Manager
14. Customizable deals and discounts
15. Gift certificates
16. Accept Payments through Square,Stripe, PayPal and Authorize.Net
17. Business analysis reports
18. Separate staff login
19. SMS customization
20. Custom booking portal, features & Integration

### Support ### 

For any help or setup support you may mail us at <a href="mailto:contact@appointy.com">contact@appointy.com</a>
You can also schedule an appointment by <a href="https://booking.appointy.com/support/?utm_source=wordpress&utm_medium=textdescription&utm_campaign=Wordpress_description" target="_blank">clicking this link</a>

**You may also call us at our 24x7 support numbers:**
24x7 Support: **USA**  <a href="tel:+1 786 766 7676">+1 786 766 7676</a>
24x7 Support: **UK**  <a href="tel:+44 20 3871 3003">+44 20 3871 3003</a>

### Why is Appointy better than other standalone Wordpress scheduling plugins ###

* Freemium plan that’s free forever. No credit card required. Affordable pricing that scales as your business grows. No hidden costs. Most Wordpress scheduling plugins just **provide basic features in the free version and then force you to buy premium add-ons** for additional critical features like payments etc. whereas **Appointy provides many of these premium features  in its free forever version** itself. As a result, the standalone Wordpress plugins with their add-ons end up being more expensive and bug ridden in the long term over Appointy.

* Other Wordpress scheduling plugins are **often plagued by poor support and long issue resolution turnaround times** but Appointy being one of the biggest players in the appointment scheduling domain, is proud to offer the highest standards of **customer support 24x7 through call/chat/email**. You can even request free setup assistance for your business.

* Other Wordpress scheduling plugins and their add-ons often create **unnecessary bloat in the Wordpress dashboard** thus slowing down your website and resulting in compatibility clashes with your theme and other plugins, whereas **Appointy is a SaaS application and all the heavy processing is managed by Appointy’s super fast cloud servers** so that processing is extremely fast and you never lose your precious data or appointments.

* Other Wordpress scheduling plugins require setting up of **server cron jobs and specialized server settings forcing you to either upgrade to higher hosting plans** or losing out on bookings/appointment reminders thus eventually affecting your business’s service quality and customer satisfaction. But with Appointy, you can set up scheduling on your website with just the **basic shared hosting plan as all the sms/email reminders, are taken care of by Appointy** with their efficient cloud service with 99.99% uptime guarantee. This saves you unnecessary hosting costs and ensures professional services to your customers. 

* Other Wordpress scheduling plugins creates **security vulnerabilities**, whereas Appointy being a SaaS application is **100% safe and integrates with your favourite payment processors** out of the box even in its free plan.

* Other Wordpress plugins which have their **working from within Wordpress remain exposed to problems caused by Wordpress version updates** leading to service downtimes and business losses whereas **Appointy being a SaaS is always resistant to compatibility and functionality issues** arising out of any such updates, thus ensuring robust performance and business reliability.

* Other scheduling plugins tend to get **limited by features** and as your requirements grow along with your business, you are forced to switch platforms which impacts your business and creates new problems. Whereas, **Appointy offers enterprise level plans and features so that as your business grows Appointy will be your growth partner** throughout your journey.

* Unlike other plugins, Appointy offers **multi platform access to your business** settings and administration. You can access Appointy on the go through our **Android and iOS apps** as well.

* Unlike other Wordpress scheduling plugins, **Appointy has several marketing and analytics features** so that you can get an edge over your competition.

* Unlike other Wordpress scheduling plugins, **Appointy has a very intuitive interface and onboarding process** which enables you to get comfortable with the system within the first 5 minutes itself. In case you need help, our 24x7 support desk is always at your disposal. Appointy also provides you with several third party software integrations.

* Several of the standalone free Wordpress plugins compromise your data and the data of your customers and are not GDPR compliant. Appointy being the one of the most trusted and reliable appointment scheduling plugins, is GDPR compliant and provides 100% security for you and your customer's data.

== Installation ==

**This section describes how to install the plugin and get it working.**

1. Login to your Wordpress admin dashboard.
2. Click the “Plugins” menu on the left and choose “Add New”.
3. Search for “WordPress Appointment Booking and Online Scheduling Plugin by Appointy” and install it.
4. After the plugin installation has finished, click the “Activate” button.
5. Click on the new “Appointy Calendar” tab that is now available on your left bar.
6. Click on the "Setup" button to setup your plugin or in case you already have an account with Appointy just enter your calendar’s URL.
7. Create a page named “Schedule an Appointment'' and paste the shortcode {APPOINTY} as a normal text to display the appointment calendar on your website.
8. To access your appointments or other settings like staff, services, customers etc., login to your account by <a href="https://www.appointy.com/?utm_source=wordpress&utm_medium=textdescription&utm_campaign=Wordpress_faq" target="_blank">clicking this link</a> 

**Note:**
* You may also upload the plugin manually  to the /wp-content/plugins/ directory and then proceed from step number 4 above.
* If your calendar overlaps your sidebar, then choose a page template, which does not have a sidebar for “Schedule an Appointment” page.

For any help or setup support you may mail us at <a href="mailto:contact@appointy.com">contact@appointy.com</a>
You can also schedule an appointment by <a href="https://booking.appointy.com/support/?utm_source=wordpress&utm_medium=textdescription&utm_campaign=Wordpress_installation" target="_blank">clicking this link</a>

**You may also call us at our 24x7 support numbers:**
24x7 Support: **USA**  <a href="tel:+1 786 766 7676">+1 786 766 7676</a>
24x7 Support: **UK**  <a href="tel:+44 20 3871 3003">+44 20 3871 3003</a>

== Frequently Asked Questions ==

= Is appointy a standalone wordpress plugin or a SaaS application? =
Appointy is one of the first and most trusted players in the appointment scheduling and booking domain throughout the world. It's a very powerful, highly customizable and feature packed SaaS application. Appointy extends its feature set to Wordpress through its Wordpress plugin which has over 100,000 downloads on Wordpress.org. 

As Appointy is a SaaS application, most of the heavy processing is done by the Appointy’s server which does not slow down your website or clutter your Wordpress dashboard. It also does not conflict with other plugins on your website.


= Can I get appointy for a one time payment? =
Appointy has a free plan which is free forever. In case you want to upgrade to a paid plan, you get the option to subscribe to monthly or annual payments-basis. There is no one time payment option but unlike other plugins which promises the world with a one time payment option but force you to buy several add ons for additional functionality, Appointy’s plans turns out to be more cost effective and feature rich in the long run.

= Who owns my data? =
You do! It's your data after all! We want customers to use Appointy because they love it, not because their data is stuck in it. You can export all of your information from Appointy at any time, no matter what plan you choose.

= What is the validity of the free plan? =
 Our free plan is free forever!. 

= Do I get free setup and support for the free plan as well? =
Yes, we value all our customers and provide free setup and 24x7 support for all our customers irrespective of the plan they choose to subscribe to.

= What kind of businesses can use Appointy scheduling plugin? =
Appointy has the ability to serve almost any business segment. This includes:
* Health & Wellness (Spa, Massage therapist, Acupuncture)
* Fitness & Recreation (Health clubs, Gyms, Personal trainers, Yoga lessons, Dance instructors)
* Medicine (Doctors, Dentists, Chiropractors, Opticians)
* Education (College and Universities, Schools, Tutoring)
* Salon & Beauty (Hair salons, Nail salons, Hair braiding, Tanning salons, Tattoo studios)
* Professional services (Attorneys, Tax consultants, Photography studios, Business, Business Coaching, Driving Schools)
* Other services (Pet walkers, Day Care centres, Hot air balloon rides, Whale watching, City tours, Interview scheduling)
* Government (Government offices, Volunteer scheduling)

= What platforms does Appointy support? =
Appointy is available as a Web App, iOS App, and Android App.

= Can I switch plans later on without losing my data? = 
Absolutely. You are free to switch between plans as per your requirement without any interruption of services or data loss.

= Can I integrate the appointment calendar on my website and accept bookings directly? =
Yes, you can integrate appointment calendar directly on your website and accept payments directly in your account.

= Can I change the look and feel of the Appointy calendar to match my website? =
Yes of course, you may change the color scheming and add custom css to the calendar to match your website’s design. You can also take help from our 24x7 support for this.

For any help or setup support you may mail us at <a href="mailto:contact@appointy.com">contact@appointy.com</a>
You can also schedule an appointment by <a href="https://booking.appointy.com/support/?utm_source=wordpress&utm_medium=textdescription&utm_campaign=Wordpress_faq" target="_blank">clicking this link</a>

**You may also call us at our 24x7 support numbers:**
24x7 Support: **USA**  <a href="tel:+1 786 766 7676">+1 786 766 7676</a>
24x7 Support: **UK**  <a href="tel:+44 20 3871 3003">+44 20 3871 3003</a>

= Do I need to hire a developer to integrate and setup Appointy on my website? =
Appointy is very intuitive and easy to use. You will find all the instructions needed to set it up on your website within the product itself. If you need additional assistance, we also have a detailed help centre with screenshots, videos, and step-by-step tutorials on how to use Appointy. Or if you prefer, you can also take help from our 24x7 customer support for any questions or troubleshooting.

= Can I accept appointments based on staff and location? =
Yes, Appointy is highly customizable and provides your freedom to take appointments as per your requirements.

= What if I need some custom features? =
Appointy is a highly scalable tool and provides flexibility for any custom requirements that you may have. You can opt for our enterprise plan and request customization as per your requirements.

== Screenshots ==

== Changelog ==

 = Appointment Booking and online Scheduling by Appointy Version 3.0 =
 * Compatibility with WordPress Plugin Guidelines

 = Appointment Booking and online Scheduling by Appointy Version 2.3 =
 * Language support for Chinese, Croatian, Czech, Danish, Estonian, French, Finnish, German, Greek, Hungarian, Italian, Japanese, Lithuanian, Latvian, Dutch, Nynorsk, Portuguese, Polish, Russian, Romanian, Spanish, Slovenian, Serbian, Slovak, Swedish, Turkish

 = Appointment Booking and online Scheduling by Appointy Version 2.2 =
 * Compatibility with WordPress 4.5

== Upgrade Notice ==

We've updated our plugin with tons of new features! Please update your plugin to enjoy them.
**For any help or support with our plugin or scheduling system please contact our <a href="https://www.appointy.com/contactus/" target="_blank">Support Desk here.</a>**

== Translations ==

Appointy appointment booking and online scheduling is available in:

* Chinese
* Croatian
* Czech
* Danish
* Estonian
* French
* Finnish
* German
* Greek
* Hungarian
* Italian
* Japanese
* Lithuanian
* Latvian
* Dutch
* Nynorsk
* Portuguese
* Polish
* Russian
* Romanian
* Spanish
* Slovenian
* Serbian
* Slovak
* Swedish
* Turkish



